﻿using System.Windows.Forms;

namespace $safeprojectname$.UI
{
    public partial class PluginEditorView : UserControl
    {
        public PluginEditorView()
        {
            InitializeComponent();
        }
    }
}
